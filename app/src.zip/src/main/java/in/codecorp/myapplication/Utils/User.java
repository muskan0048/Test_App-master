package in.codecorp.myapplication.Utils;

public class User {


}
