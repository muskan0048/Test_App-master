package in.codecorp.myapplication.Utils;

import java.util.Map;

public class TimeSpent {

    private Map<String,Answer> ans;

    public Map<String,Answer> getAns() {
        return ans;
    }

    public void setAns(Map<String,Answer> ans) {
        this.ans = ans;
    }
}