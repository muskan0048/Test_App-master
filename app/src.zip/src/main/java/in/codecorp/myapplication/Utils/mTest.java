package in.codecorp.myapplication.Utils;

public class mTest {
    String mt_id,
            user_id,
            t_id,
            mt_status,
            mt_start_date,
            mt_expiry_date,
            mt_total_marks,
            mt_marks_obt,
            mt_percentage,
            mt_result_date,
            mt_minutes_passed;
    String test;

    String t_id2,
            t_title,
            t_duration,
            t_description,
            t_instructions,
            t_order,
            t_qtype,
            t_auto_sourcedata,
            t_status,
            level_id,
            c_id;

    public mTest(String mt_id, String user_id, String t_id, String mt_status, String mt_start_date, String mt_expiry_date, String mt_total_marks, String mt_marks_obt, String mt_percentage, String mt_result_date, String mt_minutes_passed, String test, String t_id2, String t_title, String t_duration, String t_description, String t_instructions, String t_order, String t_qtype, String t_auto_sourcedata, String t_status, String level_id, String c_id) {
        this.mt_id = mt_id;
        this.user_id = user_id;
        this.t_id = t_id;
        this.mt_status = mt_status;
        this.mt_start_date = mt_start_date;
        this.mt_expiry_date = mt_expiry_date;
        this.mt_total_marks = mt_total_marks;
        this.mt_marks_obt = mt_marks_obt;
        this.mt_percentage = mt_percentage;
        this.mt_result_date = mt_result_date;
        this.mt_minutes_passed = mt_minutes_passed;
        this.test = test;
        this.t_id2 = t_id2;
        this.t_title = t_title;
        this.t_duration = t_duration;
        this.t_description = t_description;
        this.t_instructions = t_instructions;
        this.t_order = t_order;
        this.t_qtype = t_qtype;
        this.t_auto_sourcedata = t_auto_sourcedata;
        this.t_status = t_status;
        this.level_id = level_id;
        this.c_id = c_id;
    }


    public String getMt_id() {
        return mt_id;
    }

    public void setMt_id(String mt_id) {
        this.mt_id = mt_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getT_id() {
        return t_id;
    }

    public void setT_id(String t_id) {
        this.t_id = t_id;
    }

    public String getMt_status() {
        return mt_status;
    }

    public void setMt_status(String mt_status) {
        this.mt_status = mt_status;
    }

    public String getMt_start_date() {
        return mt_start_date;
    }

    public void setMt_start_date(String mt_start_date) {
        this.mt_start_date = mt_start_date;
    }

    public String getMt_expiry_date() {
        return mt_expiry_date;
    }

    public void setMt_expiry_date(String mt_expiry_date) {
        this.mt_expiry_date = mt_expiry_date;
    }

    public String getMt_total_marks() {
        return mt_total_marks;
    }

    public void setMt_total_marks(String mt_total_marks) {
        this.mt_total_marks = mt_total_marks;
    }

    public String getMt_marks_obt() {
        return mt_marks_obt;
    }

    public void setMt_marks_obt(String mt_marks_obt) {
        this.mt_marks_obt = mt_marks_obt;
    }

    public String getMt_percentage() {
        return mt_percentage;
    }

    public void setMt_percentage(String mt_percentage) {
        this.mt_percentage = mt_percentage;
    }

    public String getMt_result_date() {
        return mt_result_date;
    }

    public void setMt_result_date(String mt_result_date) {
        this.mt_result_date = mt_result_date;
    }

    public String getMt_minutes_passed() {
        return mt_minutes_passed;
    }

    public void setMt_minutes_passed(String mt_minutes_passed) {
        this.mt_minutes_passed = mt_minutes_passed;
    }

    public String getTest() {
        return test;
    }

    public void setTest(String test) {
        this.test = test;
    }

    public String getT_id2() {
        return t_id2;
    }

    public void setT_id2(String t_id2) {
        this.t_id2 = t_id2;
    }

    public String getT_title() {
        return t_title;
    }

    public void setT_title(String t_title) {
        this.t_title = t_title;
    }

    public String getT_duration() {
        return t_duration;
    }

    public void setT_duration(String t_duration) {
        this.t_duration = t_duration;
    }

    public String getT_description() {
        return t_description;
    }

    public void setT_description(String t_description) {
        this.t_description = t_description;
    }

    public String getT_instructions() {
        return t_instructions;
    }

    public void setT_instructions(String t_instructions) {
        this.t_instructions = t_instructions;
    }

    public String getT_order() {
        return t_order;
    }

    public void setT_order(String t_order) {
        this.t_order = t_order;
    }

    public String getT_qtype() {
        return t_qtype;
    }

    public void setT_qtype(String t_qtype) {
        this.t_qtype = t_qtype;
    }

    public String getT_auto_sourcedata() {
        return t_auto_sourcedata;
    }

    public void setT_auto_sourcedata(String t_auto_sourcedata) {
        this.t_auto_sourcedata = t_auto_sourcedata;
    }

    public String getT_status() {
        return t_status;
    }

    public void setT_status(String t_status) {
        this.t_status = t_status;
    }

    public String getLevel_id() {
        return level_id;
    }

    public void setLevel_id(String level_id) {
        this.level_id = level_id;
    }

    public String getC_id() {
        return c_id;
    }

    public void setC_id(String c_id) {
        this.c_id = c_id;
    }
}
